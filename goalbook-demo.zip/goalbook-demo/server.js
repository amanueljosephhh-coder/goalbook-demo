require('dotenv').config();
const express = require('express');
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const isProd = process.env.NODE_ENV === 'production';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
const SESSION_SECRET = process.env.SESSION_SECRET;
if (!ADMIN_PASSWORD || ADMIN_PASSWORD === 'change-this-demo-password') {
  console.warn('WARNING: Set a unique ADMIN_PASSWORD in your environment before exposing this demo publicly.');
}
if (!SESSION_SECRET || SESSION_SECRET.length < 32) {
  console.warn('WARNING: Set SESSION_SECRET to a random value at least 32 characters long.');
}

app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '30kb' }));
app.use(session({
  name: 'goalbook.sid',
  secret: SESSION_SECRET || crypto.randomBytes(48).toString('hex'),
  resave: false,
  saveUninitialized: false,
  store: new SQLiteStore({ db: 'sessions.sqlite', dir: process.env.SESSION_DIR || './data' }),
  cookie: { httpOnly: true, sameSite: 'lax', secure: isProd, maxAge: 8 * 60 * 60 * 1000 }
}));
app.use('/api/admin/login', rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, standardHeaders: true, legacyHeaders: false }));
app.use(express.static(path.join(__dirname, 'public')));

// Entirely fictional sample data. These odds and teams are for demonstration only.
const matches = [
  { id:'fb101', sport:'Football', league:'Demo Premier League', home:'London Lions', away:'Northbridge FC', start:'Today · 19:30', status:'upcoming', odds:{home:1.82, draw:3.35, away:4.10, over25:1.91, under25:1.87, bttsYes:1.78, bttsNo:1.98}, result:null },
  { id:'fb102', sport:'Football', league:'Demo Continental Cup', home:'Rivergate United', away:'Metro Athletic', start:'Today · 21:00', status:'upcoming', odds:{home:2.20, draw:3.10, away:3.00, over25:2.02, under25:1.76, bttsYes:1.85, bttsNo:1.91}, result:null },
  { id:'bb201', sport:'Basketball', league:'Demo Hoops League', home:'City Comets', away:'Coastal Waves', start:'Today · 20:15', status:'upcoming', odds:{home:1.68, away:2.12, over:1.90, under:1.90}, result:null },
  { id:'tn301', sport:'Tennis', league:'Demo Open', home:'Alex Morgan (fictional)', away:'Jordan Lee (fictional)', start:'Tomorrow · 14:00', status:'upcoming', odds:{home:1.74, away:2.05}, result:null },
  { id:'fb103', sport:'Football', league:'Demo City League', home:'Oldtown Rovers', away:'Eastvale Town', start:'Tomorrow · 17:45', status:'upcoming', odds:{home:2.55, draw:3.00, away:2.62, over25:1.88, under25:1.90, bttsYes:1.72, bttsNo:2.05}, result:null },
  { id:'bb202', sport:'Basketball', league:'Demo Hoops League', home:'Mountain Foxes', away:'Harbor Kings', start:'Tomorrow · 19:00', status:'upcoming', odds:{home:2.04, away:1.76, over:1.93, under:1.87}, result:null }
];
const tickets = [];
const playerBalances = new Map();
const INITIAL_BALANCE = 1000;
const OUTCOME_LABELS = {
  home:'Home win', draw:'Draw', away:'Away win', over25:'Over 2.5 goals', under25:'Under 2.5 goals',
  bttsYes:'Both teams to score — Yes', bttsNo:'Both teams to score — No', over:'Over total points', under:'Under total points'
};
function publicMatch(m) {
  return { id:m.id, sport:m.sport, league:m.league, home:m.home, away:m.away, start:m.start, status:m.status, odds:m.odds, result:m.result };
}
function outcomeCategory(key) {
  if (['home','draw','away'].includes(key)) return 'winner';
  if (['over25','under25'].includes(key)) return 'goals';
  if (['bttsYes','bttsNo'].includes(key)) return 'btts';
  if (['over','under'].includes(key)) return 'total';
  return 'winner';
}
function requiredResultCategories(match) {
  return match.sport === 'Football' ? ['winner','goals','btts'] : match.sport === 'Basketball' ? ['winner','total'] : ['winner'];
}
function ensurePlayer(req) {
  if (!req.session.playerId) req.session.playerId = crypto.randomUUID();
  if (!playerBalances.has(req.session.playerId)) playerBalances.set(req.session.playerId, INITIAL_BALANCE);
  req.session.balance = playerBalances.get(req.session.playerId);
  if (!req.session.ticketIds) req.session.ticketIds = [];
}
function requireAdmin(req, res, next) {
  if (req.session && req.session.isAdmin === true) return next();
  return res.status(401).json({ error: 'Admin sign-in required.' });
}
function validSelection(match, key) {
  return Object.prototype.hasOwnProperty.call(match.odds, key) && typeof match.odds[key] === 'number';
}
app.get('/api/health', (req,res) => res.json({ ok:true, app:'GoalBook demo', mode:'fictional-money-only' }));
app.get('/api/session', (req,res) => {
  ensurePlayer(req);
  res.json({ balance:req.session.balance, admin: req.session.isAdmin === true, demo:true });
});
app.get('/api/matches', (req,res) => res.json(matches.map(publicMatch)));
app.get('/api/tickets', (req,res) => {
  ensurePlayer(req);
  const own = tickets.filter(t => req.session.ticketIds.includes(t.id)).map(t => ({...t}));
  res.json(own);
});
app.post('/api/bets', (req,res) => {
  ensurePlayer(req);
  const stake = Number(req.body && req.body.stake);
  const selections = req.body && req.body.selections;
  if (!Number.isFinite(stake) || stake < 1 || stake > 500 || Math.round(stake * 100) !== stake * 100) return res.status(400).json({error:'Stake must be between 1 and 500 virtual credits.'});
  if (!Array.isArray(selections) || selections.length < 1 || selections.length > 8) return res.status(400).json({error:'Choose between 1 and 8 selections.'});
  if (req.session.balance < stake) return res.status(400).json({error:'Not enough virtual credits.'});
  const seen = new Set();
  let combinedOdds = 1;
  const resolved = [];
  for (const s of selections) {
    const match = matches.find(m => m.id === s.matchId);
    if (!match || match.status !== 'upcoming' || !validSelection(match, s.outcome) || seen.has(match.id)) return res.status(400).json({error:'Selection invalid, duplicated, or event closed. Choose at most one outcome per match.'});
    seen.add(match.id);
    const odds = match.odds[s.outcome];
    combinedOdds *= odds;
    resolved.push({matchId:match.id, match:`${match.home} vs ${match.away}`, sport:match.sport, outcome:s.outcome, outcomeLabel:OUTCOME_LABELS[s.outcome] || s.outcome, odds});
  }
  const ticket = { id:crypto.randomUUID().slice(0,8).toUpperCase(), playerId:req.session.playerId, createdAt:new Date().toISOString(), stake, combinedOdds:Number(combinedOdds.toFixed(2)), potentialReturn:Number((stake*combinedOdds).toFixed(2)), selections:resolved, status:'Open', result:null };
  req.session.balance = Number((req.session.balance - stake).toFixed(2));
  playerBalances.set(req.session.playerId, req.session.balance);
  req.session.ticketIds.push(ticket.id);
  tickets.unshift(ticket);
  res.json({ticket, balance:req.session.balance});
});
app.post('/api/admin/login', (req,res) => {
  const password = String((req.body && req.body.password) || '');
  if (!ADMIN_PASSWORD || ADMIN_PASSWORD === 'change-this-demo-password' || password.length > 256 || !crypto.timingSafeEqual(Buffer.from(password.padEnd(256,'\0').slice(0,256)), Buffer.from(ADMIN_PASSWORD.padEnd(256,'\0').slice(0,256)))) {
    return res.status(401).json({error:'Invalid credentials or admin password has not been configured.'});
  }
  req.session.regenerate(err => {
    if (err) return res.status(500).json({error:'Could not create admin session.'});
    req.session.isAdmin = true;
    res.json({ok:true});
  });
});
app.post('/api/admin/logout', (req,res) => {
  if (req.session) req.session.destroy(() => res.json({ok:true})); else res.json({ok:true});
});
app.get('/api/admin/overview', requireAdmin, (req,res) => res.json({
  matches:matches.map(publicMatch), tickets:tickets.map(t=>({...t, playerId:undefined})),
  stats:{events:matches.length, openTickets:tickets.filter(t=>t.status==='Open').length, settledTickets:tickets.filter(t=>t.status!=='Open').length, demoOnly:true}
}));
app.post('/api/admin/matches/:id/settle', requireAdmin, (req,res) => {
  const match = matches.find(m => m.id === req.params.id);
  const results = req.body && req.body.results;
  if (!match) return res.status(404).json({error:'Match not found.'});
  if (match.status !== 'upcoming') return res.status(400).json({error:'This demo match has already been settled.'});
  if (!results || typeof results !== 'object') return res.status(400).json({error:'Choose a result for each market group.'});
  for (const category of requiredResultCategories(match)) {
    const allowed = Object.keys(match.odds).filter(k => outcomeCategory(k) === category);
    if (!allowed.includes(results[category])) return res.status(400).json({error:`Choose a valid ${category} result.`});
  }
  match.status = 'settled'; match.result = Object.fromEntries(requiredResultCategories(match).map(c => [c, results[c]]));
  for (const t of tickets) {
    if (t.status !== 'Open' || !t.selections.some(s=>s.matchId===match.id)) continue;
    // A demo accumulator is settled when all its selected events have been resolved.
    if (!t.selections.every(s => matches.find(m=>m.id===s.matchId)?.status === 'settled')) continue;
    const won = t.selections.every(s => matches.find(m=>m.id===s.matchId)?.result?.[outcomeCategory(s.outcome)] === s.outcome);
    t.status = won ? 'Won' : 'Lost'; t.result = won ? 'Won' : 'Lost';
    if (won) {
      const current = playerBalances.get(t.playerId) || 0;
      playerBalances.set(t.playerId, Number((current + t.potentialReturn).toFixed(2)));
    }
  }
  res.json({ok:true, match:publicMatch(match)});
});
// Demo balances are server-side in-memory values. They reset when the free instance restarts.
app.use((err,req,res,next) => { console.error(err); res.status(500).json({error:'Unexpected server error.'}); });
app.listen(PORT, () => console.log(`GoalBook demo running on http://localhost:${PORT}`));
